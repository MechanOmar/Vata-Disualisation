read.csv()
Ny<- NYTBestsellers
7 >= 6
x <- 12 / 3 > 3 & 5 ^ 2 < 25
x
y <- 12 / 3 > 3 | 5 ^ 2 < 25 | 1 == 2

#Basic data types in R can be divided into the following types:
  
#numeric - (10.5, 55, 787)
#integer - (1L, 55L, 100L, where the letter "L" declares this as an integer)
#complex - (9 + 3i, where "i" is the imaginary part)
#character (a.k.a. string) - ("k", "R is exciting", "FALSE", "11.5")
#logical (a.k.a. boolean) - (TRUE or FALSE)
#We can use the class() function to check the data type of a variable:

Cake <- "The cake"
Lie <- "a lie" 

Cake==Lie  
m<-"MOHAMMED"
6<nchar(m)
#7  Make a logical expression that tests whether your name is less than 6
#letters long and is not James, Janelle, Jamil or Jessica.
m <6 & m %in% c("James", "Janelle", "Jamil", "Jessica")& m == c("James", "Janelle", "Jamil", "Jessica")
# %in% is to see if vectors match or if each string is equal to
#8
w <- 'melanogaster'#Character
x <- 1:12vector
y <- FALSE # object
z <- x + 1 # 
#9
"Even Numbers" <- for (i in 1:50) {
  print (i*2)}

seq(from = 0, to = 100, by = 2)
seq(0,100,2)
#Repeats
rep(c("a", "b", "c"), times = c(5,5,5))
#Q10) Create a vector of all the odd numbers between 1000 and 1500 that are divisible by 7.
Odd <- seq(1001,1500,2)
Odd2 <- Odd[Odd %% 5 == 0]
print( Odd2)
x[x %% 5 == 0]# %% means divide and return remainders, gives remainders that are == to 0 after the division so what you ask it to do

#11) Using the NYT bestseller data, 
#create a vector of the names all the books that were in the top spot for at least 10 weeks.
 c(Ny$title[Ny$total_weeks >= 10])

#Q12) Using the NYT bestseller data, 
#create a new dataframe where all the books were in the top spot 
#for less than 10 weeks and have titles that are less than 15 characters long.
Ny2<- Ny$title[Ny$total_weeks <10]

Ny3<- Ny2[15<nchar(Ny2)]

#Q13) Add a new column to your dataframe called ‘long10’ 
#that contains the word ‘yes’ if the book title is 10 characters long, 
#and ‘no’ if it is not."
Ny$"LONG10"<- "no" 
Ny$LONG10 [10<nchar(Ny$title)]<- "yes"

#Try creating your own new column called ‘number_of_pages’ that creates a column
#with 100 for the first 20 books, 200 for the next 20 and so on until the last
#20 books are 500. Adapt your previous answer to make use of the seq() function
#to create the input for the rep() function.
Ny$"number_of_pages"<-rep(c("100", "200", "500"), times = c(20,60,20))
